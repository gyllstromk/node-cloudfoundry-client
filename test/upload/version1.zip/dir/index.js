var app = require('restify').createServer();
app.get('/', function (req, res) {
    res.send(200);
});

app.listen(process.env.VMC_APP_PORT);
