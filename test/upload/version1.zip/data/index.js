require('restify').createServer().listen(process.env.VMC_APP_PORT);
