var app = require('restify').createServer();
app.get('/', function (req, res) {
    res.send(202);
});

app.listen(process.env.VMC_APP_PORT);
